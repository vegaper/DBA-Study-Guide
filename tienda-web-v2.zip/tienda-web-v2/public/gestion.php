<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= h($_SESSION['csrf']) ?>">
<title>Confirmar y enviar · Tienda del aula</title>
<link rel="icon" href="data:,"><link rel="stylesheet" href="style.css?v=2"><script src="gestion.js?v=2" defer></script>
</head>
<body>
<header class="topbar"><div class="brand"><span class="brand-mark" aria-hidden="true">T</span><div>Tienda del aula<small>IFCT0310 · Administración de bases de datos</small></div></div><span class="lab-tag">Laboratorio MySQL</span></header>
<main class="page">
<nav class="app-nav" aria-label="Secciones"><a href="./">Nuevo borrador</a><a class="active" href="gestion.php" aria-current="page">Confirmar y enviar</a></nav>
<section class="intro"><p class="eyebrow">DEL BORRADOR AL ENVÍO</p><h1>Seguimos cada pedido</h1><p>Consultad la compra, confirmadla y registrad su salida cuando esté preparada.</p></section>
<div id="notice" class="notice" role="status" aria-live="polite" hidden></div>
<noscript><p>Activad JavaScript para gestionar los pedidos.</p></noscript>
<section class="panel"><h2>Pedidos de la tienda</h2>
<div class="manage-tools"><label for="status-filter">Estado<select id="status-filter"><option value="">Todos</option><option>BORRADOR</option><option>PENDIENTE</option><option>ENVIADO</option></select></label><button id="refresh" class="button subtle" type="button">Actualizar pedidos</button>
<form id="find-form"><label for="find-id">Abrir por identificador<input id="find-id" type="number" min="1" max="2147483647" step="1" required></label><button class="button subtle" type="submit">Abrir pedido</button></form></div>
<p id="list-info" class="hint" role="status"></p>
<div class="table-scroll"><table class="orders"><thead><tr><th>Pedido y fecha</th><th>Cliente</th><th>Estado</th><th>Preparación</th><th>Importe</th><th>Acción</th></tr></thead><tbody id="orders"><tr><td colspan="6">Cargando pedidos…</td></tr></tbody></table></div>
<div class="pagination"><button id="previous" class="button subtle" type="button">Anterior</button><span id="page-info"></span><button id="next" class="button subtle" type="button">Siguiente</button></div>
</section>
<section id="detail" class="panel order-detail" tabindex="-1" hidden aria-labelledby="detail-title"><p class="eyebrow">DETALLE DE LA COMPRA</p><h2 id="detail-title"></h2><p id="detail-meta"></p><div id="flow" class="flow"></div>
<p id="integrity" class="notice error" hidden></p>
<div class="table-scroll"><table><thead><tr><th>Producto</th><th>Cantidad</th><th>Precio de compra</th><th>Importe</th></tr></thead><tbody id="lines"></tbody></table></div><p class="receipt-total">Importe total <strong id="detail-total"></strong></p>
<div id="confirm-area" hidden><h3>Confirmar la compra</h3><p>El pedido pasará a PENDIENTE y se creará su tarea de preparación.</p><button id="confirm" class="button primary" type="button">Confirmar pedido</button></div>
<form id="shipping-form" hidden><h3>Registrar la salida</h3><p>Rellenad los datos cuando el pedido salga del almacén. No se contratará ningún transporte real.</p><div class="shipping-fields"><label for="carrier">Transportista<input id="carrier" type="text" maxlength="80" required autocomplete="off"></label><label for="tracking">Código de seguimiento<input id="tracking" type="text" maxlength="60" required autocomplete="off"></label></div><button class="button primary" type="submit">Registrar envío</button></form>
<section id="shipment" hidden><h3>Datos para el transportista</h3><dl id="shipping-data"></dl><button id="print" class="button subtle" type="button">Imprimir ficha del pedido</button></section>
<p class="hint">Si habéis cambiado datos desde Workbench, pulsad Actualizar pedidos para consultar el estado actual.</p>
</section>
<p class="scope-note">La confirmación y el envío se ejecutan mediante los procedimientos de MySQL de la práctica.</p>
</main><footer>Tienda del aula · Versión 2 · Confirmación y envío</footer>
</body></html>
