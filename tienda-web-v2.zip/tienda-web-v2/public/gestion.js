'use strict';
const $ = id => document.getElementById(id);
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const euros = new Intl.NumberFormat('es-ES', {style:'currency', currency:'EUR'});
const money = value => euros.format(Number(value));
const state = {busy:false, page:1, pages:1, selected:null, pedido:null};
function el(tag, text, cls) { const node=document.createElement(tag); if(text!==undefined) node.textContent=text; if(cls) node.className=cls; return node; }
function notice(text, error=false) { $('notice').textContent=text; $('notice').className=`notice${error?' error':''}`; $('notice').setAttribute('role',error?'alert':'status'); $('notice').hidden=!text; }
function lock(value) {
  state.busy=value;
  document.querySelectorAll('main button, main input, main select').forEach(node=>node.disabled=value);
  $('previous').disabled=value || state.page<=1;
  $('next').disabled=value || state.page>=state.pages;
  $('confirm').disabled=value || !state.pedido || Number(state.pedido.numero_lineas)===0;
}
async function request(action, body) {
  const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),20000);
  try {
    const options={signal:controller.signal,cache:'no-store',credentials:'same-origin'};
    if(body) Object.assign(options,{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},body:JSON.stringify(body)});
    const response=await fetch(`api.php?accion=${action}`,options);
    let data; try { data=await response.json(); } catch {throw new Error('El servidor no ha devuelto datos válidos. Revisad PHP y su registro.');}
    if(!response.ok || !data.ok) throw new Error(data.mensaje || 'No se pudo completar la operación.');
    return data;
  } catch(error) {
    if(error.name==='AbortError' || error instanceof TypeError) throw new Error('No se ha recibido confirmación. Actualizad el pedido antes de repetir: la base de datos puede haber completado la operación.');
    throw error;
  } finally { clearTimeout(timer); }
}
async function loadList() {
  const d=(await request(`pedidos&estado=${encodeURIComponent($('status-filter').value)}&pagina=${state.page}`)).datos;
  state.pages=d.paginas;
  if(state.page>d.paginas) {state.page=d.paginas; return loadList();}
  $('orders').replaceChildren();
  for(const p of d.pedidos) {
    const row=el('tr');
    const idCell=el('td');idCell.append(el('strong',`#${p.id_pedido}`),el('small',p.fecha_pedido));row.append(idCell);
    for(const value of [p.cliente,p.estado_pedido,p.estado_preparacion||'Sin preparación',money(p.importe_total)]) row.append(el('td',value));
    const action=el('td');const button=el('button',`Ver pedido ${p.id_pedido}`,'button subtle');button.type='button';button.addEventListener('click',()=>openOrder(p.id_pedido));action.append(button);row.append(action);$('orders').append(row);
  }
  if(!d.pedidos.length) {const row=el('tr');const cell=el('td','No hay pedidos con este filtro.');cell.colSpan=6;row.append(cell);$('orders').append(row);}
  $('list-info').textContent=`${d.total} pedidos en este filtro. Se muestran hasta 50 por página.`;
  $('page-info').textContent=`Página ${state.page} de ${state.pages}`;
}
function renderDetail(p) {
  state.selected=p.id_pedido;state.pedido=p;
  $('detail').hidden=false;$('detail-title').textContent=`Pedido ${p.id_pedido} · ${p.estado_pedido}`;
  $('find-id').value=p.id_pedido;
  $('detail-meta').textContent=`${p.cliente} · Fecha de MySQL: ${p.fecha_pedido} · ${p.numero_lineas} líneas · ${p.total_unidades} unidades`;
  $('flow').replaceChildren();
  for(const [label,value] of [['Pedido',p.estado_pedido],['Preparación',p.estado_preparacion||'Sin tarea'],['Envío',p.envio?'Registrado':'Sin envío']]) {const box=el('div');box.append(el('span',label),el('strong',value));$('flow').append(box);}
  $('lines').replaceChildren();
  for(const l of p.lineas) {
    const row=el('tr');for(const text of [l.nombre,l.cantidad,money(l.precio_unitario),money(Number(l.precio_unitario)*Number(l.cantidad))]) row.append(el('td',text));$('lines').append(row);
  }
  if(!p.lineas.length) {const row=el('tr');const cell=el('td','El borrador no tiene productos y no puede confirmarse.');cell.colSpan=4;row.append(cell);$('lines').append(row);}
  $('detail-total').textContent=money(p.importe_total);
  const valid=(p.estado_pedido==='BORRADOR'&&!p.estado_preparacion&&!p.envio) || (p.estado_pedido==='PENDIENTE'&&p.estado_preparacion==='PENDIENTE'&&!p.envio) || (p.estado_pedido==='ENVIADO'&&p.estado_preparacion==='COMPLETADA'&&!!p.envio);
  $('integrity').hidden=valid;$('integrity').textContent='El pedido, la preparación y el envío no son coherentes. Revisad los triggers y los datos desde Workbench antes de continuar. No volváis a confirmar a ciegas.';
  $('confirm-area').hidden=!valid || p.estado_pedido!=='BORRADOR';
  $('shipping-form').hidden=!valid || p.estado_pedido!=='PENDIENTE';
  $('carrier').value='';$('tracking').value='';
  $('shipment').hidden=!p.envio;$('shipping-data').replaceChildren();
  if(p.envio) {
    for(const [label,value] of [['Transportista',p.envio.transportista],['Seguimiento',p.envio.codigo_seguimiento],['Fecha de salida',p.envio.fecha_envio],['Destinatario',p.envio.destinatario],['Dirección',p.envio.direccion_entrega],['Código postal y ciudad',`${p.envio.codigo_postal} ${p.envio.ciudad}`]]) $('shipping-data').append(el('dt',label),el('dd',value));
  }
}
async function refreshDetail(id) {
  $('detail').hidden=true;state.pedido=null;
  renderDetail((await request(`detalle&id=${id}`)).pedido);
}
async function openOrder(id) {
  if(state.busy)return; lock(true);notice('');
  try {await refreshDetail(id);$('detail').focus();}
  catch(error){notice(error.message,true);}
  finally{lock(false);}
}
async function refresh(reset=false) {
  if(state.busy)return;lock(true);notice('');if(reset)state.page=1;
  try {await loadList();if(state.selected)await refreshDetail(state.selected);}
  catch(error){notice(error.message,true);}
  finally{lock(false);}
}
async function perform(action, extra={}) {
  if(state.busy || !state.pedido)return;
  const id=state.pedido.id_pedido;let completed=false;lock(true);notice('');
  try {
    const result=await request(action,{id_pedido:id,...extra});completed=true;
    await refreshDetail(id);await loadList();
    notice(`${result.mensaje} Consultad debajo el estado actual del pedido, la preparación y el envío.`);
    $('detail').focus();
  } catch(error) {
    notice((completed?'El procedimiento terminó, pero no se pudo actualizar toda la pantalla. No repitáis el guardado; pulsad Actualizar pedidos. ':'')+error.message,true);
    // Un error o una respuesta perdida puede dejar la vista anterior obsoleta.
    if(!completed){state.pedido=null;$('detail').hidden=true;}
  } finally {lock(false);}
}
$('status-filter').addEventListener('change',()=>refresh(true));
$('refresh').addEventListener('click',()=>refresh());
$('previous').addEventListener('click',()=>{if(!state.busy&&state.page>1){state.page--;refresh();}});
$('next').addEventListener('click',()=>{if(!state.busy&&state.page<state.pages){state.page++;refresh();}});
$('find-form').addEventListener('submit',event=>{event.preventDefault();const id=Number($('find-id').value);if(Number.isInteger(id)&&id>0&&id<=2147483647)openOrder(id);});
$('confirm').addEventListener('click',()=>perform('confirmar'));
$('shipping-form').addEventListener('submit',event=>{event.preventDefault();if($('shipping-form').reportValidity())perform('enviar',{transportista:$('carrier').value,codigo_seguimiento:$('tracking').value});});
$('print').addEventListener('click',()=>window.print());
(async()=>{
  lock(true);
  try {await loadList();const id=Number(new URLSearchParams(location.search).get('pedido'));if(Number.isInteger(id)&&id>0&&id<=2147483647){await refreshDetail(id);$('detail').focus();}}
  catch(error){notice(error.message,true);$('orders').replaceChildren();}
  finally{lock(false);}
})();
