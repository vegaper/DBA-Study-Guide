# Tienda del aula versión 2

Aplicación PHP y MySQL para crear borradores, confirmar pedidos y registrar envíos.
Ampliación independiente de la práctica IFCT0310. PHP 8.2 o superior con PDO_MYSQL y MySQL 8.4.x.
Uso de aula con datos ficticios, en vuestra red de laboratorio. La selección de cliente no es autenticación y la aplicación no incluye usuarios web ni contratación real de transporte.

## Requisitos SQL para Confirmar y enviar

Deben estar creados y probados estos cinco objetos de la práctica:
- `vista_resumen_pedidos`, con sus columnas originales.
- `sp_confirmar_pedido(IN INT)`.
- `sp_registrar_envio(IN INT, IN VARCHAR(80), IN VARCHAR(60))`.
- `trg_pedidos_au`, sobre UPDATE de pedidos.
- `trg_envios_ai`, sobre INSERT de envios.

El paquete NO contiene las soluciones de esos objetos. Utilizad los que habéis creado en la práctica y verificad que respetan el contrato de la guía. La creación de borradores sigue funcionando sin ellos; la página de gestión sí los necesita.

## Actualizar una instalación existente

1. Guardad una copia de la carpeta actual, fuera de su carpeta pública. Conservad el archivo `config/config.php` y sus permisos.
2. Extraed este ZIP en otra carpeta. Copiad `app` y `public` sobre las carpetas del mismo nombre de `/opt/tienda-borradores`. Copiad también `sql/03_permisos_gestion.sql` y `sql/04_comprobar_ciclo.sql` a su carpeta sql.
3. No copiéis una configuración vacía sobre vuestro `config/config.php`. No ejecutéis el script inicial ni volváis a crear la cuenta existente.
4. Como administrador, revisad y ejecutad `sql/03_permisos_gestion.sql` en la base ya existente. Para PHP en otro equipo, cambiad localhost en todas las cuentas por la IP del servidor PHP.
5. Abrid `/tienda-borradores/` y pulsad Confirmar y enviar. Si se conserva código antiguo, recargad con Ctrl+F5 y reiniciad Apache si utiliza caché de PHP.

Los procedimientos de referencia son SQL SECURITY INVOKER: la cuenta necesita EXECUTE y permisos de lectura, UPDATE de la columna estado en pedidos e INSERT en envios. Los triggers actúan con los permisos de su DEFINER. La aplicación solo llama a las rutinas para esas acciones; estos permisos no son una barrera de acceso exclusivo por procedimientos para quien conozca las credenciales MySQL.

## Instalación rápida en Ubuntu Server con Apache

1. Partid de MySQL 8.4.x y la base `tienda_online_practica` ya cargada. Si MySQL está en Windows u otro equipo, no instaléis otra MySQL para esta app.
2. Instalad los componentes web:

```bash
sudo apt update
sudo apt install apache2 php php-cli libapache2-mod-php php-mysql unzip
php -v
php -r 'echo implode(", ", PDO::getAvailableDrivers()), PHP_EOL;'
```

La última salida debe incluir `mysql`. La versión concreta de PHP dependerá de los paquetes de vuestra Ubuntu.

3. Con el ZIP en vuestra carpeta personal, extraedlo y copiad la aplicación:

```bash
unzip Tienda_online_App_v2_Confirmar_y_enviar.zip
sudo mkdir -p /opt/tienda-borradores
sudo cp -r tienda-borradores/. /opt/tienda-borradores/
sudo chown -R root:root /opt/tienda-borradores
sudo chmod -R u=rwX,go=rX /opt/tienda-borradores
```

4. En Workbench, con la cuenta administradora, revisad y ejecutad `sql/01_usuario_app.sql`.
   Para PHP y MySQL en el mismo equipo el ejemplo usa `'tienda_app'@'localhost'`.
   Si están separados, sustituid `localhost` en todas las cuentas por la IP del servidor PHP. Cambiad la contraseña de ejemplo.

5. Preparad la conexión:

```bash
sudo cp /opt/tienda-borradores/config/config.example.php /opt/tienda-borradores/config/config.php
sudo nano /opt/tienda-borradores/config/config.php
sudo chown root:www-data /opt/tienda-borradores/config/config.php
sudo chmod 640 /opt/tienda-borradores/config/config.php
```

`host` es la IP de MySQL vista desde PHP. Con PHP y MySQL en Ubuntu podéis usar `localhost` para el socket local. Conservad el host que ya os funciona; `127.0.0.1` fuerza TCP/IP y requiere que MySQL escuche allí. Indicad la misma cuenta y contraseña que habéis preparado en MySQL.

6. Una vez instalados y probados los objetos SQL de la práctica, ejecutad como administrador `sql/03_permisos_gestion.sql`, adaptando el host de la cuenta si procede.

7. Cread `/etc/apache2/conf-available/tienda-borradores.conf` con este contenido:

```apache
Alias /tienda-borradores /opt/tienda-borradores/public
<Directory /opt/tienda-borradores/public>
    Options -Indexes
    AllowOverride None
    DirectoryIndex index.php
    Require all granted
</Directory>
```

Publicamos solo `public`, por lo que `app`, `config` y `sql` no forman parte de la URL.

```bash
sudo a2enconf tienda-borradores
sudo apache2ctl configtest
sudo systemctl restart apache2
```

Esperado: `Syntax OK`. Abrid `http://IP_DEL_SERVIDOR_WEB/tienda-borradores/`.

## MySQL en otro equipo

- El navegador conecta con Apache en el puerto web. PHP conecta con MySQL en su puerto, normalmente 3306.
- `config.php` debe señalar la IP de MySQL; la cuenta MySQL debe aceptar conexiones desde la IP del servidor PHP.
- MySQL debe escuchar en una interfaz accesible desde PHP y el cortafuegos debe permitir esa conexión.
- Dos VMs en la misma Red NAT pueden comunicarse, pero el ordenador anfitrión no accede directamente a sus servicios por ese motivo. Para usar el navegador del anfitrión necesitáis una red accesible, por ejemplo un adaptador puente o una red solo anfitrión, o una redirección de puertos correctamente configurada.
- La guía Word explica cómo distinguir un problema de red, de PHP y de permisos.

## Prueba rápida sin Apache

Con PHP, PDO_MYSQL y `config.php` ya preparados, desde la raíz de la aplicación:

```bash
php -S 127.0.0.1:8000 -t public
```

Abrid `http://127.0.0.1:8000/` EN ESE MISMO EQUIPO. Este servidor está destinado a pruebas locales. Si utilizáis un navegador de otro equipo, seguid el despliegue Apache.

## Ejemplo reproducible

Seleccionad Hugo Díaz, añadid un Teclado USB y dos unidades de Memoria USB 64 GB.
Con los precios iniciales: dos líneas, tres unidades, 54,90 euros.
Pulsad Guardar borrador y anotad el identificador real. En Workbench abrid `sql/02_comprobar_borrador.sql`, sustituid el 0 de la variable por ese identificador y ejecutadlo.
Debe haber una cabecera BORRADOR, las dos líneas, cero preparaciones y cero envíos para ese pedido.


## Recorrido desde el navegador

- Nuevo borrador: cliente y productos, resumen y guardado de cabecera y líneas en una transacción.
- El recibo ofrece Confirmar este pedido, que abre su ficha en la segunda sección.
- Confirmar y enviar: listado de hasta 50 pedidos por página, filtro por estado y apertura por identificador.
- En un BORRADOR con productos aparece Confirmar pedido. El botón ejecuta el procedimiento; el trigger crea la preparación PENDIENTE.
- En un PENDIENTE con preparación pendiente aparece el formulario de transportista y seguimiento. Registrar envío llama al procedimiento; los triggers pasan el pedido a ENVIADO y completan la preparación.
- Un ENVIADO muestra la ficha de transporte con destinatario y dirección capturados en envios; podéis imprimirla.
- La pantalla avisa y bloquea acciones si detecta estados incoherentes entre pedido, preparación y envío. Se revisan desde Workbench; no se reparan automáticamente.

Después de cada operación se releen los datos de la base. Si se corta la conexión, actualizad antes de repetir. Las rutinas rechazan repetir una confirmación o un envío; no se reintentan automáticamente las escrituras. El botón queda desactivado durante la petición. Los borradores conservan la protección de repetición de la versión 1 (sesión y últimos 30 recibos).

## Orden del laboratorio

Realizad la ampliación después de las pruebas P01 a P17 y de su balance final, o en una copia de laboratorio aparte. Crear, confirmar y enviar pedidos altera recuentos y estados. El primer pedido generado puede ocupar el ID 21 usado por una prueba original. Usad siempre el identificador real del recibo.

## Archivos de interés

- `Guia_App_v2_Confirmar_y_enviar.docx`: actualización, requisitos SQL, permisos, recorrido y comprobaciones.
- `sql/00_tienda_online_inicial.sql`: copia del original, únicamente para una base todavía inexistente.
- `sql/01_usuario_app.sql`: creación inicial de la cuenta, únicamente cuando no exista.
- `sql/03_permisos_gestion.sql`: permisos adicionales de esta versión.
- `sql/04_comprobar_ciclo.sql`: lecturas de comprobación desde Workbench; sustituir el ID 0.
- `app/gestion.php`: lecturas y llamadas parametrizadas a procedimientos. No reproduce sus escrituras.

## Verificación de la entrega

Se han ejecutado las rutinas, los triggers, la vista y los permisos en MySQL 8.4.7 con un contexto de ejecución equivalente a tienda_app, incluyendo rechazos por borrador vacío, doble confirmación, doble envío y rollback ante seguimiento duplicado. Se han superado 19 pruebas PHP del nuevo módulo y 24 del guardado original. El recorrido de navegador se ha comprobado con datos ficticios mediante un adaptador SQLite exclusivo de pruebas. Ese adaptador no se distribuye. La conexión PDO_MYSQL y Apache de vuestro servidor se verifican al instalar; no se ha accedido a vuestro entorno.

Fuentes: manual de MySQL 8.4 sobre seguridad de objetos almacenados, manual de PHP sobre PDOStatement::closeCursor y PDO_MYSQL. Enlaces en la guía Word.
