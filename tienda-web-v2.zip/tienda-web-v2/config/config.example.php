<?php
declare(strict_types=1);
// Copiad este archivo como config.php y completad los datos de vuestra MySQL.
// La carpeta config está fuera del directorio público del servidor web.
return [
    'host' => 'localhost',       // IP del SERVIDOR MySQL vista desde PHP.
    'port' => 3306,
    'database' => 'tienda_online_practica',
    'username' => 'tienda_app',
    'password' => 'CAMBIAR_POR_LA_CLAVE_DEL_USUARIO',
];
