<?php
declare(strict_types=1);

// La vista y los dos procedimientos son los creados en la práctica SQL.
// Este archivo no reproduce sus UPDATE ni sus INSERT ni abre transacciones al hacer CALL.
function idPedido(mixed $id): int
{
    if (!enteroEnRango($id, 1, 2147483647)) {
        throw new ErrorFormulario('Indicad un identificador de pedido entero y positivo.');
    }
    return $id;
}

function resumenGestion(array $p): array
{
    foreach (['id_pedido', 'numero_lineas', 'total_unidades'] as $field) {
        $p[$field] = (int)$p[$field];
    }
    // La vista puede incluir pedidos vacíos con importe cero.
    $p['importe_total'] = (string)$p['importe_total'];
    return $p;
}

function listarPedidos(PDO $db, string $estado, int $pagina): array
{
    if (!in_array($estado, ['', 'BORRADOR', 'PENDIENTE', 'ENVIADO'], true)
        || $pagina < 1 || $pagina > 100000) {
        throw new ErrorFormulario('El filtro o la página no son válidos.');
    }
    $where = $estado === '' ? '' : ' WHERE estado_pedido = ?';
    $params = $estado === '' ? [] : [$estado];
    $count = $db->prepare('SELECT COUNT(*) FROM vista_resumen_pedidos' . $where);
    $count->execute($params);
    $total = (int)$count->fetchColumn();
    $offset = ($pagina - 1) * 50;
    // El desplazamiento se calcula a partir de un entero ya validado.
    $q = $db->prepare('SELECT * FROM vista_resumen_pedidos' . $where . " ORDER BY id_pedido DESC LIMIT 50 OFFSET $offset");
    $q->execute($params);
    return ['pedidos' => array_map('resumenGestion', $q->fetchAll()), 'total' => $total, 'pagina' => $pagina, 'paginas' => max(1, (int)ceil($total / 50))];
}

function detalleGestion(PDO $db, int $id): array
{
    $q = $db->prepare('SELECT * FROM vista_resumen_pedidos WHERE id_pedido = ?');
    $q->execute([$id]);
    $p = $q->fetch();
    if (!$p) throw new ErrorFormulario('El pedido no existe.', 404);
    $q = $db->prepare('SELECT d.id_producto, pr.nombre, d.cantidad, d.precio_unitario FROM detalle_pedido d INNER JOIN productos pr ON pr.id_producto = d.id_producto WHERE d.id_pedido = ? ORDER BY d.id_detalle');
    $q->execute([$id]);
    $p['lineas'] = $q->fetchAll();
    $q = $db->prepare('SELECT id_envio, transportista, codigo_seguimiento, fecha_envio, destinatario, direccion_entrega, codigo_postal, ciudad FROM envios WHERE id_pedido = ?');
    $q->execute([$id]);
    $p['envio'] = $q->fetch() ?: null;
    return resumenGestion($p);
}

function textoEnvio(mixed $value, int $max, string $nombre): string
{
    if (!is_string($value) || !preg_match('//u', $value)) throw new ErrorFormulario("El campo $nombre no es válido.");
    $value = trim($value);
    $length = preg_match_all('/./us', $value);
    if ($value === '' || $length > $max || preg_match('/[\x00-\x1F\x7F]/u', $value)) {
        throw new ErrorFormulario("El campo $nombre es obligatorio, sin caracteres de control y con un máximo de $max caracteres.");
    }
    return $value;
}

function ejecutarAccion(PDO $db, string $accion, array $body): int
{
    $id = idPedido($body['id_pedido'] ?? null);
    if ($db->inTransaction()) throw new RuntimeException('CALL necesita una conexión sin transacción abierta.');
    // Nombres de rutinas fijos. Ningún nombre de SQL procede del navegador.
    if ($accion === 'confirmar') {
        $sql = 'CALL sp_confirmar_pedido(?)';
        $params = [$id];
    } elseif ($accion === 'enviar') {
        $sql = 'CALL sp_registrar_envio(?, ?, ?)';
        $params = [$id, textoEnvio($body['transportista'] ?? null, 80, 'transportista'), textoEnvio($body['codigo_seguimiento'] ?? null, 60, 'código de seguimiento')];
    } else {
        throw new ErrorFormulario('Operación no disponible.', 400);
    }
    $q = $db->prepare($sql);
    $q->execute($params);
    // Consumir todos los resultados del CALL libera la conexión para consultas posteriores.
    while ($q->nextRowset()) { /* Las rutinas de referencia no devuelven tablas. */ }
    $q->closeCursor();
    return $id;
}
