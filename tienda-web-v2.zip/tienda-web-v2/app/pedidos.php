<?php
declare(strict_types=1);

final class ErrorFormulario extends RuntimeException
{
    public function __construct(string $message, public int $status = 422)
    {
        parent::__construct($message);
    }
}

// Evita calcular dinero con números de coma flotante: 24.90 se representa como 2490.
function aCentimos(string $precio): int
{
    if (!preg_match('/\A(\d{1,8})\.(\d{2})\z/', $precio, $m)) {
        throw new RuntimeException('Precio de catálogo no válido.');
    }
    $value = ((int)$m[1] * 100) + (int)$m[2];
    if ($value <= 0) {
        throw new RuntimeException('El precio debe ser positivo.');
    }
    return $value;
}

function enteroEnRango(mixed $value, int $min, int $max): bool
{
    return is_int($value) && $value >= $min && $value <= $max;
}

// Acepta únicamente los identificadores, cantidades y precios mostrados al preparar la compra.
// Los precios recibidos se comparan después con los que realmente hay en MySQL.
function normalizarSolicitud(array $body): array
{
    if (!enteroEnRango($body['id_cliente'] ?? null, 1, 2147483647)) {
        throw new ErrorFormulario('Seleccionad un cliente válido.');
    }
    $rows = $body['lineas'] ?? null;
    if (!is_array($rows) || !array_is_list($rows) || count($rows) < 1 || count($rows) > 100) {
        throw new ErrorFormulario('Añadid entre 1 y 100 productos al borrador.');
    }
    $items = [];
    foreach ($rows as $row) {
        if (!is_array($row)
            || !enteroEnRango($row['id_producto'] ?? null, 1, 2147483647)
            || !enteroEnRango($row['cantidad'] ?? null, 1, 1000)
            || !enteroEnRango($row['precio_centimos'] ?? null, 1, 9999999999)) {
            throw new ErrorFormulario('Cada producto necesita una cantidad entera entre 1 y 1000 y un precio válido.');
        }
        $id = $row['id_producto'];
        if (isset($items[$id]) && $items[$id]['precio_centimos'] !== $row['precio_centimos']) {
            throw new ErrorFormulario('Un producto repetido tiene precios distintos. Actualizad el catálogo.', 409);
        }
        $qty = ($items[$id]['cantidad'] ?? 0) + $row['cantidad'];
        if ($qty > 1000) {
            throw new ErrorFormulario('El máximo es de 1000 unidades por producto.');
        }
        $items[$id] = ['id_producto' => $id, 'cantidad' => $qty, 'precio_centimos' => $row['precio_centimos']];
    }
    ksort($items, SORT_NUMERIC);
    return ['id_cliente' => $body['id_cliente'], 'lineas' => array_values($items)];
}

function catalogo(PDO $db): array
{
    $clientes = $db->query('SELECT id_cliente, nombre, direccion, codigo_postal, ciudad FROM clientes ORDER BY nombre, id_cliente')->fetchAll();
    $productos = $db->query('SELECT id_producto, nombre, precio_actual FROM productos ORDER BY nombre, id_producto')->fetchAll();
    foreach ($clientes as &$c) {
        $c['id_cliente'] = (int)$c['id_cliente'];
    }
    unset($c);
    foreach ($productos as &$p) {
        $p['id_producto'] = (int)$p['id_producto'];
        $p['precio_centimos'] = aCentimos((string)$p['precio_actual']);
    }
    unset($p);
    return ['clientes' => $clientes, 'productos' => $productos];
}

function guardarBorrador(PDO $db, array $pedido): array
{
    if ($db->inTransaction()) {
        throw new RuntimeException('El guardado necesita una conexión sin transacciones previas.');
    }
    $db->beginTransaction();
    try {
        // Mantiene estables el cliente y los precios mientras guardamos.
        $qCliente = $db->prepare('SELECT id_cliente, nombre FROM clientes WHERE id_cliente = ? FOR SHARE');
        $qCliente->execute([$pedido['id_cliente']]);
        $cliente = $qCliente->fetch();
        if (!$cliente) {
            throw new ErrorFormulario('El cliente seleccionado ya no existe. Actualizad la página.', 409);
        }
        $ids = array_column($pedido['lineas'], 'id_producto');
        $marks = implode(',', array_fill(0, count($ids), '?'));
        $qProductos = $db->prepare("SELECT id_producto, nombre, precio_actual FROM productos WHERE id_producto IN ($marks) ORDER BY id_producto FOR SHARE");
        $qProductos->execute($ids);
        $productos = [];
        foreach ($qProductos->fetchAll() as $p) {
            $productos[(int)$p['id_producto']] = $p;
        }
        $lineas = [];
        $total = 0;
        $unidades = 0;
        foreach ($pedido['lineas'] as $item) {
            $p = $productos[$item['id_producto']] ?? null;
            if (!$p) {
                throw new ErrorFormulario('Algún producto ya no existe. Actualizad el catálogo.', 409);
            }
            $precio = aCentimos((string)$p['precio_actual']);
            if ($precio !== $item['precio_centimos']) {
                throw new ErrorFormulario('Han cambiado los precios. Actualizad el catálogo y revisad el resumen antes de guardar.', 409);
            }
            $subtotal = $precio * $item['cantidad'];
            $total += $subtotal;
            $unidades += $item['cantidad'];
            $lineas[] = ['id_producto' => $item['id_producto'], 'nombre' => $p['nombre'], 'cantidad' => $item['cantidad'], 'precio_centimos' => $precio, 'subtotal_centimos' => $subtotal, 'precio_sql' => (string)$p['precio_actual']];
        }
        // Una sola cabecera, con identificador generado por MySQL.
        $insertPedido = $db->prepare("INSERT INTO pedidos (id_cliente, estado) VALUES (?, 'BORRADOR')");
        $insertPedido->execute([$pedido['id_cliente']]);
        $idPedido = (int)$db->lastInsertId();
        // Se obtiene antes de insertar las líneas y antes de confirmar la transacción.
        if ($idPedido <= 0) {
            throw new RuntimeException('No se pudo recuperar el identificador del pedido.');
        }
        $insertLinea = $db->prepare('INSERT INTO detalle_pedido (id_pedido, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)');
        foreach ($lineas as &$linea) {
            $insertLinea->execute([$idPedido, $linea['id_producto'], $linea['cantidad'], $linea['precio_sql']]);
            unset($linea['precio_sql']);
        }
        unset($linea);
        $qFecha = $db->prepare('SELECT fecha_pedido FROM pedidos WHERE id_pedido = ?');
        $qFecha->execute([$idPedido]);
        $fecha = (string)$qFecha->fetchColumn();
        $db->commit();
        return ['id_pedido' => $idPedido, 'estado' => 'BORRADOR', 'fecha_pedido' => $fecha, 'cliente' => $cliente['nombre'], 'id_cliente' => $pedido['id_cliente'], 'lineas' => $lineas, 'numero_lineas' => count($lineas), 'total_unidades' => $unidades, 'total_centimos' => $total];
    } catch (Throwable $e) {
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        throw $e;
    }
}
