<?php
declare(strict_types=1);

function conectar(): PDO
{
    $path = dirname(__DIR__) . '/config/config.php';
    if (!is_file($path)) {
        throw new RuntimeException('Falta config/config.php. Copiad config.example.php y configurad la conexión.');
    }
    $c = require $path;
    if (!is_array($c) || !isset($c['host'], $c['port'], $c['database'], $c['username'], $c['password'])) {
        throw new RuntimeException('La configuración de conexión está incompleta.');
    }
    // DSN solo se construye con configuración administrada, nunca con el formulario.
    foreach (['host', 'database'] as $field) {
        if (!is_string($c[$field]) || !preg_match('/\A[a-zA-Z0-9_.:-]+\z/', $c[$field])) {
            throw new RuntimeException('Revisad host y database en config.php.');
        }
    }
    $port = filter_var($c['port'], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 65535]]);
    if ($port === false) {
        throw new RuntimeException('Revisad el puerto en config.php.');
    }
    if (!extension_loaded('pdo_mysql')) {
        throw new RuntimeException('PHP necesita la extensión pdo_mysql. Revisad la instalación.');
    }
    return new PDO(
        "mysql:host={$c['host']};port={$port};dbname={$c['database']};charset=utf8mb4",
        $c['username'],
        $c['password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5,
            PDO::MYSQL_ATTR_MULTI_STATEMENTS => false,
        ]
    );
}
