<?php
declare(strict_types=1);

// Errores técnicos al registro de PHP; la respuesta web se controla en api.php.
ini_set('display_errors', '0');
ini_set('log_errors', '1');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
header('Cache-Control: no-store');
session_name('TIENDA_BORRADORES');
session_set_cookie_params([
    'httponly' => true,
    'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
    'samesite' => 'Strict',
    'path' => '/',
]);
session_start();
$_SESSION['csrf'] ??= bin2hex(random_bytes(32));
$_SESSION['draft_tokens'] ??= [];
$_SESSION['receipts'] ??= [];

function nuevoTokenBorrador(): string
{
    $token = bin2hex(random_bytes(24));
    $_SESSION['draft_tokens'][$token] = time();
    // Límite de formularios simultáneos en la misma sesión.
    while (count($_SESSION['draft_tokens']) > 30) {
        unset($_SESSION['draft_tokens'][array_key_first($_SESSION['draft_tokens'])]);
    }
    return $token;
}
