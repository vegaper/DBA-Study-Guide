-- Ejecutar con una cuenta administradora EN EL SERVIDOR MYSQL.
-- Requisito: ya existe tienda_online_practica y sus tablas.
-- Ejemplo para Apache/PHP y MySQL EN EL MISMO EQUIPO.
-- Cambiad la contraseña de ejemplo y copiad esa misma clave en config/config.php.
-- No se crean tablas, vistas, procedimientos ni triggers.

CREATE USER 'tienda_app'@'localhost'
  IDENTIFIED BY 'Aula_Tienda_2026!Cambiar';
GRANT SELECT ON tienda_online_practica.clientes
  TO 'tienda_app'@'localhost';
GRANT SELECT ON tienda_online_practica.productos
  TO 'tienda_app'@'localhost';
GRANT SELECT, INSERT ON tienda_online_practica.pedidos
  TO 'tienda_app'@'localhost';
GRANT INSERT ON tienda_online_practica.detalle_pedido
  TO 'tienda_app'@'localhost';
SHOW GRANTS FOR 'tienda_app'@'localhost';

-- Si PHP está en OTRO equipo, no ejecutéis sin adaptar el bloque anterior:
-- sustituid localhost en TODAS las cuentas por la IP del servidor PHP.
-- Ejemplo de sintaxis de cuenta: 'tienda_app'@'192.168.100.30'
-- El host de config.php será, en cambio, la IP del servidor MYSQL.
-- Si la cuenta ya existe, revisadla con SHOW GRANTS y actualizadla expresamente.
-- Este archivo se detiene ante errores; no reemplaza ni elimina cuentas.
