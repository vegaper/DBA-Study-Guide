-- Lecturas de comprobación. Usar vuestra cuenta de prácticas en Workbench.
USE tienda_online_practica;
SET @id_pedido_web = 0; -- SUSTITUIR por el identificador real del recibo.
SELECT * FROM vista_resumen_pedidos WHERE id_pedido = @id_pedido_web;
SELECT * FROM detalle_pedido WHERE id_pedido = @id_pedido_web ORDER BY id_detalle;
SELECT * FROM preparacion_pedidos WHERE id_pedido = @id_pedido_web;
SELECT * FROM envios WHERE id_pedido = @id_pedido_web;
-- BORRADOR: sin preparación y sin envío.
-- Tras confirmar: pedido PENDIENTE, una preparación PENDIENTE y sin envío.
-- Tras enviar: pedido ENVIADO, la misma preparación COMPLETADA y un envío.
