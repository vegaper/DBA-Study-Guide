-- Ejecutar en Workbench con la cuenta habitual de prácticas.
-- Sustituid 0 por el identificador que muestra el recibo de la aplicación.
-- No se presupone que el siguiente pedido sea 21.
USE tienda_online_practica;
SET @id_borrador = 0;

SELECT id_pedido, id_cliente, fecha_pedido, estado
FROM pedidos WHERE id_pedido = @id_borrador;

SELECT id_detalle, id_pedido, id_producto, cantidad, precio_unitario,
       cantidad * precio_unitario AS importe_linea
FROM detalle_pedido WHERE id_pedido = @id_borrador
ORDER BY id_producto;

SELECT COUNT(*) AS numero_lineas,
       COALESCE(SUM(cantidad), 0) AS total_unidades,
       COALESCE(SUM(cantidad * precio_unitario), 0.00) AS importe_total
FROM detalle_pedido WHERE id_pedido = @id_borrador;

SELECT COUNT(*) AS tareas_de_preparacion
FROM preparacion_pedidos WHERE id_pedido = @id_borrador;
SELECT COUNT(*) AS envios_del_pedido
FROM envios WHERE id_pedido = @id_borrador;

-- Esperado justo después de usar la app:
-- Una cabecera BORRADOR, las líneas elegidas, cero tareas y cero envíos.
-- Para el ejemplo teclado (1 x 29.90) y USB (2 x 12.50):
-- 2 líneas, 3 unidades e importe 54.90.
