-- VERSION 2. Ejecutar COMO ADMINISTRADOR en MySQL, después de crear los
-- objetos de la práctica. La cuenta tienda_app debe existir previamente.
-- No instala ni sustituye las soluciones de vistas, procedimientos o triggers.
-- PHP y MySQL en el mismo equipo: localhost.
-- Si PHP está en otro equipo, sustituir localhost en TODAS las cuentas
-- de este archivo por la IP del servidor PHP (no la del navegador).

GRANT SELECT ON tienda_online_practica.vista_resumen_pedidos TO 'tienda_app'@'localhost';
-- La vista es SQL SECURITY INVOKER: requiere lectura de sus tablas.
GRANT SELECT ON tienda_online_practica.detalle_pedido TO 'tienda_app'@'localhost';
GRANT SELECT ON tienda_online_practica.preparacion_pedidos TO 'tienda_app'@'localhost';
GRANT SELECT ON tienda_online_practica.envios TO 'tienda_app'@'localhost';
-- Los procedimientos de referencia son SQL SECURITY INVOKER.
-- EXECUTE no basta: necesitan las operaciones que realizan sus cuerpos.
GRANT UPDATE (estado) ON tienda_online_practica.pedidos TO 'tienda_app'@'localhost';
GRANT INSERT ON tienda_online_practica.envios TO 'tienda_app'@'localhost';
GRANT EXECUTE ON PROCEDURE tienda_online_practica.sp_confirmar_pedido TO 'tienda_app'@'localhost';
GRANT EXECUTE ON PROCEDURE tienda_online_practica.sp_registrar_envio TO 'tienda_app'@'localhost';
SHOW GRANTS FOR 'tienda_app'@'localhost';
-- Los triggers se ejecutan con los permisos de su DEFINER, que debe existir
-- y poder insertar/completar preparaciones. No concedemos TRIGGER a la web.
-- Si se recrean las rutinas, revisar y volver a aplicar estos permisos.
