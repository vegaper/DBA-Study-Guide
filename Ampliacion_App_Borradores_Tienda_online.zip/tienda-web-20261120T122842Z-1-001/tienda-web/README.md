# Aplicación para crear borradores de pedidos

Ampliación independiente de la práctica Tienda online de IFCT0310.
PHP 8.2 o superior, PDO_MYSQL y MySQL 8.4.x con InnoDB. No necesita Composer, Node ni servicios externos.

## Qué hace

- Lee los clientes y productos de la base configurada.
- Permite buscar productos, añadirlos, cambiar cantidades y quitarlos.
- Une en una sola línea las repeticiones de un mismo producto.
- Guarda una cabecera BORRADOR en `pedidos` y sus líneas en `detalle_pedido`.
- Conserva el precio actual del producto como precio de compra.
- Si el precio cambió desde que se cargó el catálogo, rechaza el guardado y pide actualizarlo.
- Confirma cabecera y líneas en una sola transacción; si falla una línea, revierte la operación.
- Muestra un recibo con el identificador generado, productos, cantidades e importe.

La aplicación no modifica el esquema y no necesita la vista, los procedimientos ni los triggers. No confirma pedidos ni genera preparaciones o envíos.

Seleccionar un cliente indica a nombre de quién creamos el pedido. No equivale a iniciar sesión como esa persona. El uso previsto es el laboratorio del aula.

## Orden respecto a la práctica original

Si vais a ejecutar las pruebas P01 a P17, utilizad la aplicación DESPUÉS de completar su balance final.
La aplicación genera pedidos nuevos con AUTO_INCREMENT y, en una carga inicial, puede ocupar el identificador 21 que la prueba P17 utiliza expresamente.
Para volver al punto inicial, el docente debe restaurar la base y reinstalar los objetos que procedan. No volváis a ejecutar el script inicial sobre una base existente.

## Estructura

- `public/`: único directorio que debe publicar Apache o el servidor de prueba PHP.
- `app/`: conexión, validaciones, consultas y guardado transaccional.
- `config/config.example.php`: plantilla. Copiar a `config.php` y editar.
- `sql/00_tienda_online_inicial.sql`: copia sin cambios del script de la práctica; solo para una base que todavía no exista.
- `sql/01_usuario_app.sql`: cuenta y permisos de la aplicación; ejecutar como administrador y adaptar contraseña y host.
- `sql/02_comprobar_borrador.sql`: consultas para comprobar el identificador mostrado por la web desde Workbench.
- `Guia_App_Borradores_Tienda_online.docx`: guía paso a paso.

## Instalación rápida en Ubuntu Server con Apache

1. Partid de MySQL 8.4.x y la base `tienda_online_practica` ya cargada. Si MySQL está en Windows u otro equipo, no instaléis otra MySQL para esta app.
2. Instalad los componentes web:

```bash
sudo apt update
sudo apt install apache2 php php-cli libapache2-mod-php php-mysql unzip
php -v
php -r 'echo implode(", ", PDO::getAvailableDrivers()), PHP_EOL;'
```

La última salida debe incluir `mysql`. La versión concreta de PHP dependerá de los paquetes de vuestra Ubuntu.

3. Con el ZIP en vuestra carpeta personal, extraedlo y copiad la aplicación:

```bash
unzip Ampliacion_App_Borradores_Tienda_online.zip
sudo mkdir -p /opt/tienda-borradores
sudo cp -r tienda-borradores/. /opt/tienda-borradores/
sudo chown -R root:root /opt/tienda-borradores
sudo chmod -R u=rwX,go=rX /opt/tienda-borradores
```

4. En Workbench, con la cuenta administradora, revisad y ejecutad `sql/01_usuario_app.sql`.
   Para PHP y MySQL en el mismo equipo el ejemplo usa `'tienda_app'@'localhost'`.
   Si están separados, sustituid `localhost` en todas las cuentas por la IP del servidor PHP. Cambiad la contraseña de ejemplo.

5. Preparad la conexión:

```bash
sudo cp /opt/tienda-borradores/config/config.example.php /opt/tienda-borradores/config/config.php
sudo nano /opt/tienda-borradores/config/config.php
sudo chown root:www-data /opt/tienda-borradores/config/config.php
sudo chmod 640 /opt/tienda-borradores/config/config.php
```

`host` es la IP de MySQL vista desde PHP. Usad `127.0.0.1` si ambos servicios están en el mismo equipo. Indicad la misma cuenta y contraseña que habéis preparado en MySQL.

6. Cread `/etc/apache2/conf-available/tienda-borradores.conf` con este contenido:

```apache
Alias /tienda-borradores /opt/tienda-borradores/public
<Directory /opt/tienda-borradores/public>
    Options -Indexes
    AllowOverride None
    DirectoryIndex index.php
    Require all granted
</Directory>
```

Publicamos solo `public`, por lo que `app`, `config` y `sql` no forman parte de la URL.

```bash
sudo a2enconf tienda-borradores
sudo apache2ctl configtest
sudo systemctl restart apache2
```

Esperado: `Syntax OK`. Abrid `http://IP_DEL_SERVIDOR_WEB/tienda-borradores/`.

## MySQL en otro equipo

- El navegador conecta con Apache en el puerto web. PHP conecta con MySQL en su puerto, normalmente 3306.
- `config.php` debe señalar la IP de MySQL; la cuenta MySQL debe aceptar conexiones desde la IP del servidor PHP.
- MySQL debe escuchar en una interfaz accesible desde PHP y el cortafuegos debe permitir esa conexión.
- Dos VMs en la misma Red NAT pueden comunicarse, pero el ordenador anfitrión no accede directamente a sus servicios por ese motivo. Para usar el navegador del anfitrión necesitáis una red accesible, por ejemplo un adaptador puente o una red solo anfitrión, o una redirección de puertos correctamente configurada.
- La guía Word explica cómo distinguir un problema de red, de PHP y de permisos.

## Prueba rápida sin Apache

Con PHP, PDO_MYSQL y `config.php` ya preparados, desde la raíz de la aplicación:

```bash
php -S 127.0.0.1:8000 -t public
```

Abrid `http://127.0.0.1:8000/` EN ESE MISMO EQUIPO. Este servidor está destinado a pruebas locales. Si utilizáis un navegador de otro equipo, seguid el despliegue Apache.

## Ejemplo reproducible

Seleccionad Hugo Díaz, añadid un Teclado USB y dos unidades de Memoria USB 64 GB.
Con los precios iniciales: dos líneas, tres unidades, 54,90 euros.
Pulsad Guardar borrador y anotad el identificador real. En Workbench abrid `sql/02_comprobar_borrador.sql`, sustituid el 0 de la variable por ese identificador y ejecutadlo.
Debe haber una cabecera BORRADOR, las dos líneas, cero preparaciones y cero envíos para ese pedido.

## Comportamiento de las repeticiones y errores

El botón se bloquea mientras se guarda. Una repetición del mismo formulario y contenido en la misma sesión puede recuperar el recibo ya guardado, sin insertar otro pedido. Nuevo borrador abre otro formulario y permite crear otra compra.
La protección de repetición se conserva en la sesión PHP, con un máximo de 30 recibos. No constituye una deduplicación global entre navegadores. Si la conexión se corta justo al guardar y no recibís respuesta, comprobad el último pedido antes de abrir otro formulario.
La selección aún no guardada está en la memoria de la página: recargarla la descarta. Actualizar catálogo, en cambio, conserva las cantidades de los productos que siguen existiendo y actualiza sus precios.

## Verificación realizada

- Sintaxis revisada con PHP 8.4.27 y JavaScript.
- 24 comprobaciones de validación, importes y reversión con PDO y SQLite de prueba; solo el adaptador de pruebas retira FOR SHARE.
- Las consultas preparadas y los permisos del archivo SQL ejecutados sobre MySQL 8.4.7 con el esquema original.
- Flujo del navegador comprobado con un catálogo ficticio y almacenamiento de prueba: cliente, producto repetido, resumen y guardado completo.
- La conexión PDO_MYSQL a vuestra instancia y Apache de vuestro laboratorio se verifica al instalar; no hemos accedido a vuestro servidor.

## Errores habituales

- No carga el catálogo: revisar base cargada, `config.php`, permisos y `pdo_mysql`.
- Access denied en el registro PHP: revisar usuario, contraseña y host de la cuenta MySQL.
- Connection refused o tiempo agotado: revisar IP, puerto, servicio y red entre PHP y MySQL.
- Se descarga o muestra código PHP: Apache no está interpretando PHP; revisar el módulo o el servicio PHP configurado.
- Página no encontrada: comprobar Alias, ruta de instalación y activación con a2enconf.
- Los precios cambiaron: pulsar Actualizar catálogo, revisar importe y volver a guardar.
- Error de sesión o formulario caducado: recargar para crear otro formulario; antes, comprobar si el pedido llegó a guardarse.
- La fecha no coincide con el reloj del navegador: la fecha procede del servidor MySQL; revisar su configuración horaria.

Fuentes de instalación y funcionamiento: documentación de Ubuntu Server, manual de PHP sobre PDO y transacciones y manual MySQL 8.4 sobre lecturas con bloqueo. Enlaces completos en la guía Word.
