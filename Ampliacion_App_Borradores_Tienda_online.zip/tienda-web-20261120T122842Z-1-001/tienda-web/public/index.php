<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
$draft = nuevoTokenBorrador();
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?= h($_SESSION['csrf']) ?>">
  <meta name="draft-token" content="<?= h($draft) ?>">
  <meta name="description" content="Aplicación de aula para crear borradores en la base de datos tienda_online_practica.">
  <title>Nuevo borrador · Tienda del aula</title>
  <link rel="icon" href="data:,">
  <link rel="stylesheet" href="style.css">
  <script src="app.js" defer></script>
</head>
<body>
<header class="topbar"><div class="brand"><span class="brand-mark" aria-hidden="true">T</span><div>Tienda del aula<small>IFCT0310 · Administración de bases de datos</small></div></div><span class="lab-tag">Laboratorio MySQL</span></header>
<main class="page">
  <section class="intro"><p class="eyebrow">GESTIÓN DE PEDIDOS</p><h1>Preparamos un nuevo borrador</h1><p>Elegid un cliente, añadid los productos y revisad la compra antes de guardarla.</p></section>
  <div id="notice" class="notice" role="status" aria-live="polite" hidden></div>
  <noscript><p class="notice error">Activad JavaScript en el navegador para utilizar el formulario.</p></noscript>
  <div id="workspace" class="workspace">
    <div class="builder">
      <section class="panel customer-panel"><div class="section-heading"><span class="step">1</span><h2>Elegid el cliente</h2></div>
        <label for="client">Cliente de la base de datos</label>
        <select id="client" disabled><option value="">Cargando clientes…</option></select>
        <p id="client-address" class="hint">La cabecera quedará vinculada al cliente que seleccionéis.</p>
      </section>
      <section class="panel catalog-panel"><div class="section-heading"><span class="step">2</span><h2>Añadid los productos</h2><span id="catalog-count" class="count">—</span></div>
        <div class="catalog-tools"><label class="search-label" for="search">Buscar en el catálogo<input type="search" id="search" placeholder="Nombre o identificador del producto" disabled autocomplete="off"></label><button class="button subtle" id="reload" type="button">Actualizar catálogo</button></div>
        <div id="catalog" class="catalog" aria-live="polite"><p class="empty">Cargando productos de MySQL…</p></div>
      </section>
    </div>
    <aside class="panel summary" aria-labelledby="summary-title"><div class="section-heading"><span class="step">3</span><h2 id="summary-title">Revisad el borrador</h2></div><span class="status draft">BORRADOR</span>
      <p class="summary-intro">La compra se guardará al pulsar el botón final.</p>
      <div id="cart" class="cart"><div class="cart-empty"><span class="empty-symbol" aria-hidden="true">+</span><h3>Vuestra compra empieza aquí</h3><p>Añadid al menos un producto del catálogo.</p></div></div>
      <div class="totals"><div><span>Productos diferentes</span><strong id="line-count">0</strong></div><div><span>Unidades</span><strong id="unit-count">0</strong></div><div class="total"><span>Importe total</span><strong id="total">0,00 €</strong></div></div>
      <p class="hint">Precios de catálogo. Sin impuestos ni gastos de envío adicionales en esta práctica.</p>
      <button id="save" class="button primary" type="button" disabled>Guardar borrador</button><p id="save-help" class="save-help">Seleccionad un cliente y añadid productos.</p>
      <button id="clear" class="button text-button" type="button" disabled>Vaciar selección</button>
    </aside>
  </div>
  <section id="receipt" class="panel receipt" tabindex="-1" hidden aria-labelledby="receipt-title"><span class="success-mark" aria-hidden="true">✓</span><p class="eyebrow">GUARDADO CORRECTAMENTE</p><h2 id="receipt-title">Borrador creado</h2><p id="receipt-message"></p><div id="receipt-meta" class="receipt-meta"></div><div class="table-scroll"><table><thead><tr><th>Producto</th><th>Unidades</th><th>Precio</th><th>Importe</th></tr></thead><tbody id="receipt-lines"></tbody></table></div><p class="receipt-total">Importe total <strong id="receipt-total"></strong></p><p class="next-step">El pedido está en BORRADOR. Anotad su identificador para continuar con los procedimientos y triggers de la práctica.</p><div class="receipt-actions"><a class="button primary" href="./">Nuevo borrador</a><button id="print" class="button subtle" type="button">Imprimir resumen</button></div></section>
  <section class="scope-note"><strong>Una compra, dos tablas.</strong> Guardamos una cabecera en <code>pedidos</code> y una línea por producto en <code>detalle_pedido</code>.</section>
</main>
<footer>Práctica de tienda online · Aplicación para crear borradores</footer>
</body>
</html>
