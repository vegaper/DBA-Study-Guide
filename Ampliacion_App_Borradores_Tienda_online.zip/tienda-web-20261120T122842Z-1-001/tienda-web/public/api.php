<?php
declare(strict_types=1);
require dirname(__DIR__) . '/app/bootstrap.php';
require dirname(__DIR__) . '/app/db.php';
require dirname(__DIR__) . '/app/pedidos.php';
header('Content-Type: application/json; charset=utf-8');

function responder(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    exit;
}

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['accion'] ?? '') === 'catalogo') {
        responder(['ok' => true, 'datos' => catalogo(conectar())]);
    }
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || ($_GET['accion'] ?? '') !== 'guardar') {
        responder(['ok' => false, 'mensaje' => 'Operación no disponible.'], 405);
    }
    if (!hash_equals($_SESSION['csrf'], $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '')) {
        responder(['ok' => false, 'mensaje' => 'La sesión del formulario ha cambiado. Recargad la página.'], 403);
    }
    if (!str_starts_with(strtolower($_SERVER['CONTENT_TYPE'] ?? ''), 'application/json')) {
        responder(['ok' => false, 'mensaje' => 'El formulario debe enviar datos JSON.'], 415);
    }
    $raw = file_get_contents('php://input', false, null, 0, 32769);
    if ($raw === false || strlen($raw) > 32768) {
        responder(['ok' => false, 'mensaje' => 'El formulario supera el tamaño permitido.'], 413);
    }
    $body = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
    if (!is_array($body)) {
        throw new ErrorFormulario('El formulario no es válido.');
    }
    $token = $body['borrador_token'] ?? '';
    if (!is_string($token) || !preg_match('/\A[a-f0-9]{48}\z/', $token)) {
        throw new ErrorFormulario('El formulario ha caducado. Recargad la página.', 403);
    }
    $pedido = normalizarSolicitud($body);
    $hash = hash('sha256', json_encode($pedido, JSON_THROW_ON_ERROR));
    // La sesión PHP serializa las peticiones de este navegador: una repetición
    // del mismo guardado recupera el recibo, sin volver a insertar la compra.
    if (isset($_SESSION['receipts'][$token])) {
        $saved = $_SESSION['receipts'][$token];
        if (!hash_equals($saved['hash'], $hash)) {
            throw new ErrorFormulario('Este formulario ya guardó otro borrador. Pulsad Nuevo borrador.', 409);
        }
        responder(['ok' => true, 'pedido' => $saved['pedido'], 'repetido' => true]);
    }
    if (!isset($_SESSION['draft_tokens'][$token])) {
        throw new ErrorFormulario('El formulario ha caducado. Recargad la página.', 403);
    }
    $receipt = guardarBorrador(conectar(), $pedido);
    $_SESSION['receipts'][$token] = ['hash' => $hash, 'pedido' => $receipt];
    unset($_SESSION['draft_tokens'][$token]);
    while (count($_SESSION['receipts']) > 30) {
        unset($_SESSION['receipts'][array_key_first($_SESSION['receipts'])]);
    }
    responder(['ok' => true, 'pedido' => $receipt, 'repetido' => false], 201);
} catch (JsonException $e) {
    responder(['ok' => false, 'mensaje' => 'Los datos enviados no tienen un formato válido.'], 400);
} catch (ErrorFormulario $e) {
    responder(['ok' => false, 'mensaje' => $e->getMessage()], $e->status);
} catch (Throwable $e) {
    error_log('[tienda-borradores] ' . $e->getMessage());
    $message = $e instanceof PDOException
        ? 'No se pudo completar la operación con MySQL. Revisad la conexión, los permisos y el registro de PHP. Si estabais guardando, verificad el último pedido antes de repetir.'
        : 'Revisad config/config.php y la instalación de PHP con pdo_mysql. El registro de PHP contiene el detalle.';
    responder(['ok' => false, 'mensaje' => $message], 503);
}
