'use strict';

const $ = (id) => document.getElementById(id);
const euros = new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR' });
const money = (cents) => euros.format(cents / 100);
const state = { clients: [], products: [], cart: new Map(), loading: true, saving: false };
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const draftToken = document.querySelector('meta[name="draft-token"]').content;
const clean = (value) => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

function element(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}
function notice(message, error = false) {
  $('notice').textContent = message;
  $('notice').className = `notice${error ? ' error' : ''}`;
  $('notice').setAttribute('role', error ? 'alert' : 'status');
  $('notice').hidden = !message;
}
async function request(action, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20000);
  try {
    const response = await fetch(`api.php?accion=${action}`, { ...options, signal: controller.signal, credentials: 'same-origin', cache: 'no-store' });
    let data;
    try { data = await response.json(); } catch { throw new Error('El servidor no ha devuelto una respuesta válida. Revisad la instalación de PHP.'); }
    if (!response.ok || !data.ok) throw new Error(data.mensaje || 'No se pudo completar la operación.');
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('No se ha recibido confirmación a tiempo. Si estabais guardando, reintentad sin cambiar la selección o comprobad el último pedido.');
    if (error instanceof TypeError) throw new Error('No se pudo conectar con la aplicación. Comprobad la red; si estabais guardando, verificad el último pedido antes de repetir.');
    throw error;
  } finally { clearTimeout(timer); }
}
function updateControls() {
  const locked = state.loading || state.saving;
  $('client').disabled = locked || !state.clients.length;
  $('search').disabled = locked || !state.products.length;
  $('reload').disabled = locked;
  $('clear').disabled = locked || !state.cart.size;
  $('save').disabled = locked || !state.cart.size || !$('client').value;
  $('save').textContent = state.saving ? 'Guardando borrador…' : 'Guardar borrador';
  $('save-help').textContent = state.saving ? 'Estamos guardando la compra.' : (!state.cart.size || !$('client').value ? 'Seleccionad un cliente y añadid productos.' : 'Se guardará una cabecera y todas sus líneas.');
  document.querySelectorAll('#catalog button, #cart button, #cart input').forEach(el => { el.disabled = locked; });
}
function address() {
  const c = state.clients.find(c => c.id_cliente === Number($('client').value));
  $('client-address').textContent = c ? `${c.direccion} · ${c.codigo_postal} ${c.ciudad}` : 'La cabecera quedará vinculada al cliente que seleccionéis.';
  updateControls();
}
function renderCatalog() {
  const query = clean($('search').value.trim());
  const products = state.products.filter(p => clean(p.nombre).includes(query) || String(p.id_producto).includes(query));
  $('catalog').replaceChildren();
  $('catalog-count').textContent = `${products.length} productos`;
  if (!products.length) $('catalog').append(element('p', 'empty', 'No hay productos que coincidan con la búsqueda.'));
  for (const p of products) {
    const card = element('article', 'product');
    card.append(element('span', 'product-ref', `PRODUCTO ${String(p.id_producto).padStart(2, '0')}`));
    card.append(element('h3', '', p.nombre));
    const bottom = element('div', 'product-bottom');
    bottom.append(element('strong', 'price', money(p.precio_centimos)));
    const button = element('button', 'button add', '+ Añadir');
    button.type = 'button';
    button.dataset.product = p.id_producto;
    button.setAttribute('aria-label', `Añadir ${p.nombre}`);
    button.addEventListener('click', () => {
      const old = state.cart.get(p.id_producto);
      if (old?.cantidad >= 1000) { notice('El máximo es de 1000 unidades por producto.', true); return; }
      state.cart.set(p.id_producto, { ...p, cantidad: (old?.cantidad || 0) + 1 });
      notice(`${p.nombre}: ${state.cart.get(p.id_producto).cantidad} unidades en la selección.`);
      renderCart();
    });
    bottom.append(button); card.append(bottom); $('catalog').append(card);
  }
  updateControls();
}
function renderCart() {
  const cart = $('cart'); cart.replaceChildren();
  let units = 0; let total = 0;
  if (!state.cart.size) {
    const empty = element('div', 'cart-empty');
    const sign = element('span', 'empty-symbol', '+'); sign.setAttribute('aria-hidden', 'true');
    empty.append(sign, element('h3', '', 'Vuestra compra empieza aquí'), element('p', '', 'Añadid al menos un producto del catálogo.')); cart.append(empty);
  }
  for (const p of state.cart.values()) {
    units += p.cantidad; total += p.cantidad * p.precio_centimos;
    const row = element('div', 'cart-row');
    const heading = element('div', 'cart-row-heading');
    heading.append(element('h3', '', p.nombre));
    const remove = element('button', 'remove', 'Quitar'); remove.type = 'button';
    remove.setAttribute('aria-label', `Quitar ${p.nombre}`);
    remove.addEventListener('click', () => { state.cart.delete(p.id_producto); renderCart(); });
    heading.append(remove); row.append(heading);
    const line = element('div', 'cart-row-controls');
    const label = element('label', 'quantity-label', 'Unidades');
    const input = element('input', 'quantity'); input.type = 'number'; input.min = '1'; input.max = '1000'; input.step = '1'; input.value = p.cantidad;
    input.setAttribute('aria-label', `Unidades de ${p.nombre}`);
    input.addEventListener('change', () => {
      const qty = Number(input.value);
      if (!Number.isInteger(qty) || qty < 1 || qty > 1000) { notice('La cantidad debe ser un número entero entre 1 y 1000.', true); input.value = p.cantidad; return; }
      p.cantidad = qty; notice(''); renderCart();
    });
    label.append(input); line.append(label, element('span', 'unit-price', `${money(p.precio_centimos)} / ud.`), element('strong', 'subtotal', money(p.precio_centimos * p.cantidad)));
    row.append(line); cart.append(row);
  }
  $('line-count').textContent = state.cart.size;
  $('unit-count').textContent = units;
  $('total').textContent = money(total);
  updateControls();
}
async function loadCatalog() {
  if (state.saving) return;
  state.loading = true; notice(''); updateControls();
  const selected = $('client').value;
  try {
    const data = (await request('catalogo')).datos;
    state.clients = data.clientes; state.products = data.productos;
    $('client').replaceChildren(element('option', '', 'Seleccionad un cliente…')); $('client').options[0].value = '';
    for (const c of state.clients) { const option = element('option', '', `${c.nombre} · cliente ${c.id_cliente}`); option.value = c.id_cliente; $('client').append(option); }
    $('client').value = selected;
    let updated = false;
    for (const [id, p] of state.cart) {
      const current = state.products.find(item => item.id_producto === id);
      if (!current) { state.cart.delete(id); updated = true; }
      else { if (p.precio_centimos !== current.precio_centimos) updated = true; state.cart.set(id, { ...current, cantidad: p.cantidad }); }
    }
    renderCatalog(); renderCart(); address();
    if (updated) notice('Hemos actualizado la selección con el catálogo actual. Revisad los productos y el importe antes de guardar.');
    if (!state.clients.length || !state.products.length) notice('Faltan clientes o productos. Comprobad la carga del script inicial.', true);
  } catch (error) {
    state.clients = []; state.products = [];
    $('client').replaceChildren(element('option', '', 'No se pudieron cargar los clientes'));
    $('catalog').replaceChildren(element('p', 'empty', 'El catálogo no está disponible. Revisad el mensaje y pulsad Actualizar catálogo.'));
    notice(error.message, true);
  } finally { state.loading = false; updateControls(); }
}
function showReceipt(pedido) {
  $('workspace').hidden = true;
  $('receipt').hidden = false;
  $('receipt-title').textContent = `Pedido ${pedido.id_pedido} · BORRADOR`;
  $('receipt-message').textContent = 'La cabecera y todas las líneas se han guardado correctamente.';
  $('receipt-meta').replaceChildren();
  for (const [label, value] of [['Cliente', pedido.cliente], ['Fecha del servidor MySQL', pedido.fecha_pedido], ['Productos / unidades', `${pedido.numero_lineas} / ${pedido.total_unidades}`]]) {
    const box = element('div', ''); box.append(element('span', '', label), element('strong', '', value)); $('receipt-meta').append(box);
  }
  $('receipt-lines').replaceChildren();
  for (const line of pedido.lineas) {
    const row = element('tr', '');
    for (const text of [line.nombre, line.cantidad, money(line.precio_centimos), money(line.subtotal_centimos)]) row.append(element('td', '', text));
    $('receipt-lines').append(row);
  }
  $('receipt-total').textContent = money(pedido.total_centimos);
  $('receipt').focus();
}
$('client').addEventListener('change', address);
$('search').addEventListener('input', renderCatalog);
$('reload').addEventListener('click', loadCatalog);
$('clear').addEventListener('click', () => { state.cart.clear(); notice(''); renderCart(); });
$('print').addEventListener('click', () => window.print());
$('save').addEventListener('click', async () => {
  if (state.saving || state.loading || !$('client').value || !state.cart.size) return;
  state.saving = true; notice(''); updateControls();
  const body = { id_cliente: Number($('client').value), borrador_token: draftToken, lineas: Array.from(state.cart.values(), p => ({ id_producto: p.id_producto, cantidad: p.cantidad, precio_centimos: p.precio_centimos })) };
  try {
    const data = await request('guardar', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(body) });
    showReceipt(data.pedido);
  } catch (error) { notice(error.message, true); }
  finally { state.saving = false; updateControls(); }
});
loadCatalog();
